import React, { useState } from "react";
import { DatePicker, space } from "antd";

import { useDispatch } from "react-redux";
import { getAllProperties } from "../../Store/Property/property-action";
import { propertyAction } from "../../Store/Property/property-slice";
const Search = () => {
  const { RangePicker } = DatePicker;
  const [keyword, setkeyword] = useState({});
  const [value, setValue] = useState([]);

  const dispatch = useDispatch();
  function searchHandler(e) {
    e.preventDefault();
    dispatch(propertyAction.updateSearchParams(keyword));
    dispatch(getAllProperties());
    setkeyword({

      city:"",
      guests:"",
      dateIn:"",
      dateOut:"",
    });
    setValue([])
  }

  function returnDates(date, dateString) {
    setValue([date[0], date[1]]);
    updateKeyword("dateIn", dateString[0]);
    updateKeyword("dateOut", dateString[1]);
  }

  const updateKeyword = (field, value) => {
    setkeyword((prevKeyword) => ({
      ...prevKeyword,
      [field]: value,
    }));
  };

  return (
    <>
      <div className="searchbar">
        <input
          className="search"
          id="Search_destination"
          placeholder="Search destinations"
          type="text"
          value={keyword.city}
          onChange={(e) => updateKeyword("city", e.target.value)}
        />
        <space direction="vertical" size={12} className="search">
          <RangePicker
            value={value}
            format="YYYY-MM-DD"
            picker="date"
            className="date_picker"
            disabledDate={(current) => {
              return current && current.isBefore(Date.now(), "day");
            }}
            onChange={returnDates}
          />
        </space>
        <input
          className="search"
          id="addguest"
          placeholder="Add guest"
          type="number"
          value={keyword.guests}
          onChange={(e) => updateKeyword("guests", e.target.value)}
        />
        {/*Search icon*/}
        <span class="material-symbols-outlined searchicon" onClick={searchHandler}>Search</span>
      </div>
    </>
  );
};

export default Search;
